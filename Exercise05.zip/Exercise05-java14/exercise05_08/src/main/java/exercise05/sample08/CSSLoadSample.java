package exercise05.sample08;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * CSSファイルを読み込むのサンプル
 * ボタンが押されたときの見た目を変更している
 * @author 出展：日向俊二著「JavaFX&Java8プログラミング」
 */
public class CSSLoadSample extends Application {

    /**
     * GUIのメインメソッド
     * @param stage
     * @throws Exception 
     */
     @Override
    public void start(Stage stage) throws Exception {
        stage.setTitle("CSSLoad");
        stage.setWidth(240);
        stage.setHeight(120);
  
        VBox root = new VBox();
        Label lbl = new Label("Hello");
        Button btn = new Button("Click me!");
        btn.setOnAction(event -> lbl.setText("Clicked"));
        /*
         setOnActionは押されたときの反応を定義できる。通常ボタン操作は
         これで問題ないが、OnActionイベントだけだと離されたときに対応しない。
         押されたときと離されたときそれぞれに動作を割り当てたい場合には、
         マウスイベントのボタンが押された(MousePressed)、離された(MouseReleased)
         イベントで反応するように以下のように書く
        　//マウスが押された場合のイベント処理
        　//btn.setOnMousePressed(event -> lbl.setText("Clicked")); // 表示を変える
        　//マウスが離された場合のイベント処理
        　//btn.setOnMouseReleased(event -> lbl.setText("Hello")); //元に戻す
         */
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(10, 10, 10, 10));
        root.setSpacing(20.0);
        root.getChildren().addAll(lbl, btn);

        // CSSファイルの読み込み
        String style = getClass().getResource("sample.css").toExternalForm();
        // CSSファイル中の定義の補足：
        // buttonが通常時のデザイン
        // button:armedが押されたときのデザイン
        
        Scene scene = new Scene(root);
        // シーンへのCSS設定の割り当て
        scene.getStylesheets().add(style);
        // 画面構成の設定と表示
        stage.setScene(scene);
        stage.show();
    }
    
    /**
     * JavaFXアプリケーションを起動するだけのメインメソッド
     * ※基本的にはこの内容で固定と考えてよい
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);  // JavaFXアプリケーションを起動する
    }
}
