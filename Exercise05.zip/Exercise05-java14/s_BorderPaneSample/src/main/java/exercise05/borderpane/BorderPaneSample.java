package exercise05.borderpane;

import javafx.application.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * JavaFXのBorderPaneのサンプル
 * @author Kazuhiko Sato
 */
public class BorderPaneSample extends Application{
    @Override
    public void start(Stage stage) throws Exception {
        stage.setTitle("BorderPaneサンプル");
        stage.setWidth(320);
        stage.setHeight(140);
        
        Label lblStatus = new Label();
        
        //-------------------------------------------
        // Topに配置するボタン
        //-------------------------------------------
        Button btnTop = new Button("Top Button");
        btnTop.setPrefWidth(310);
        btnTop.setPrefHeight(30);
        // 押されたときのアクションを設定
        btnTop.setOnAction(event->lblStatus.setText("Topがクリックされました"));
        
        //-------------------------------------------
        // Centerに配置するボタン
        //-------------------------------------------
        Button btnCenter = new Button("Center Button");
        btnCenter.setPrefWidth(160);
        btnCenter.setPrefHeight(30);
        btnCenter.setMinSize(160,30);
        // 押されたときのアクションを設定
        btnCenter.setOnAction(event->lblStatus.setText("Centerがクリックされました"));

        //-------------------------------------------
        // Bottomに配置するボタン
        //-------------------------------------------
        Button btnBottom = new Button("Bottom Button");
        btnBottom.setPrefWidth(310);
        btnBottom.setPrefHeight(30);
        // 押されたときのアクションを設定
        btnBottom.setOnAction(event->lblStatus.setText("Bottomがクリックされました"));
        
        //-------------------------------------------
        // Leftに配置するボタン
        //-------------------------------------------
        Button btnLeft = new Button("Left Button");
        btnLeft.setPrefHeight(30);
        // 押されたときのアクションを設定
        btnLeft.setOnAction(event->lblStatus.setText("Leftがクリックされました"));
        
        //-------------------------------------------
        // Rightに配置するボタン
        //-------------------------------------------
        Button btnRight = new Button("Right Button");
        btnRight.setPrefHeight(30);
        // 押されたときのアクションを設定
        btnRight.setOnAction(event->lblStatus.setText("Rightがクリックされました"));
        
        //============================================
        // ボタンを並べるBorderPaneのレイアウト
        //============================================
        BorderPane border = new BorderPane();
        border.setTop(btnTop);
        border.setLeft(btnLeft);
        border.setCenter(btnCenter);
        border.setRight(btnRight);
        border.setBottom(btnBottom);
        
        //============================================
        // ラベルとボタンを並べたBorderを縦配置するVBoxレイアウト
        //============================================
        VBox base = new VBox();
        base.getChildren().addAll(border,lblStatus);
        
        //-------------------------------------------
        // StageにSceneを設定し、描画開始
        //-------------------------------------------
        stage.setScene(new Scene(base));
        stage.show();
        
    }
    
    /**
     * 起動用のmainメソッド
     * @param args 
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
