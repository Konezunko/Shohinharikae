package exercise05.sample06;

import static javafx.application.Application.launch;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

/**
 * FXMLによるGUIデザインのサンプル
 * @author 出展：日向俊二著「JavaFX&Java8プログラミング」
 */
public class FxmlSample extends Application {
    /**
     * GUIのメインメソッド
     * @param stage
     * @throws Exception 
     */
    @Override
    public void start(Stage stage) throws Exception 
    {
        stage.setTitle("FxmlSample");
        
        // FXMLファイルの読み込み
        FXMLLoader fxml = new FXMLLoader(getClass().getResource("fxmlSample.fxml"));
        // FXMLファイルからGUIデザインを構成し，ルートペインに配置
        // その他のソースの中にあるfxmlSample.fxmlで、ラベルの幅を180、高さを50に設定している
        HBox root = fxml.load();
        
        // 画面への割り当てと表示
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    /**
     * JavaFXアプリケーションを起動するだけのメインメソッド
     * ※基本的にはこの内容で固定と考えてよい
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);  // JavaFXアプリケーションを起動する
    }
}
