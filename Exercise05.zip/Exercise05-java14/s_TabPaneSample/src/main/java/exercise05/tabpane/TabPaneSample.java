package exercise05.tabpane;

import java.nio.file.Paths;
import javafx.application.*;
import javafx.beans.value.*;
import javafx.geometry.Pos;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.*;

/**
 * タブペインを使用したサンプル
 * @author Kazuhiko Sato
 */
public class TabPaneSample extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        // ベースとなるタブペインの生成
        TabPane tabPane = new TabPane();
        
        // 各タブを個別に削除できないようにする
	tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
        // 課題１：↑をコメント化して実行し，タブに削除ボタンが追加されていることを確認する。
        
        // タブを３枚生成
        Tab tab1 = new Tab("tab1");
        Tab tab2 = new Tab("tab2");
        Tab tab3 = new Tab("tab3");
        
        // タブに張り付けるための画像(Image)を用意
        Image img1 = new Image(Paths.get("images/himawari.jpg").toUri().toString());
        Image img2 = new Image(Paths.get("images/sakura.jpg").toUri().toString());
        
        // 背景イメージ(BackgroundImage)を作成する
        BackgroundImage bimg1 = new BackgroundImage(img1,null,null,null,null);
        BackgroundImage bimg2 = new BackgroundImage(img2,null,null,null,null);
        
        // ラベル上に画像を背景として割り当てる
        Label lbl1 = new Label();
        lbl1.setBackground(new Background(bimg1)); // 新しい背景(Background)に背景イメージ(BackgroundImage)を指定
        lbl1.setMinSize(img1.getWidth(),img1.getHeight()); // ラベルのサイズ(幅と高さ)を指定

        // もう１枚のラベル背景も同様に割り当てる
        Label lbl2 = new Label();
        lbl2.setBackground(new Background(bimg2));
        lbl2.setMinSize(img2.getWidth(),img2.getHeight());

        // タブの中央に配置したいので先にラベルをVBox上に張り付ける
        VBox pane1 = new VBox();
        pane1.setAlignment(Pos.CENTER);
        pane1.setPrefSize(600, 600);    // 配置領域を画面サイズに統一
        pane1.getChildren().add(lbl1);  // タブ１のペイン上に配置

        VBox pane2 = new VBox();
        pane2.setAlignment(Pos.CENTER);
        pane2.setPrefSize(600, 600);    // 配置領域を画面サイズに統一
        pane2.getChildren().add(lbl2);  // タブ２のペイン上に配置
        
        // タブ３に配置する「タブを増やすボタン」を生成
        Button btn = new Button("タブを増やす");
        btn.setOnAction(event->addNewTab(tabPane));
        
        // タブ３のボタンも画面中央に配置するためVBox上に張り付ける
        VBox pane3 = new VBox();
        pane3.setAlignment(Pos.CENTER);
        pane3.setPrefSize(600, 600);   // 配置領域を画面サイズに統一
        pane3.getChildren().add(btn);  // タブ３のペイン上に配置
		
        // それぞれのタブにコントロールを配置したVBoxペインを張り付ける
        tab1.setContent(pane1);
        tab2.setContent(pane2);
        tab3.setContent(pane3);
        
    	// タブをタブペインに登録
        tabPane.getTabs().addAll(tab1, tab2, tab3);
        
        // 選択時にメッセージを出力するようにリスナーを設定(あまり普通は利用しない)
        // リスナーは、ChangeListener#changed(ObservableValue<? extends T> observable, T oldValue, T newValue)
        tabPane.getSelectionModel().selectedItemProperty().addListener((ObservableValue<? extends Tab> obs, Tab ot, Tab nt) -> {
            //otに以前のタブ，ntに今選択されたタブが格納されているので、getTextでそのタブのタイトルを取得している
            //タブが削除されたことによる変化(これも選択とみなされる)の結果タブが無くなったときはnullが返される
            //使う際は以下(86-90)の処理部だけを書き換えてそのまま真似できるので、82行目の構文は理解できなくてもOK
            if(nt == null){
                System.out.println("All tabs were deleted.");
            }else{
                System.out.println(nt.getText()+" was selected.");
            }
        });

        // 画面へのタブの配置と出力
        BorderPane root = new BorderPane(tabPane);
        Scene scene = new Scene(root, 600, 600);
        stage.setScene(scene);
        
        //ウィンドウを可視化する
        stage.show();
    }
    
    /**
     * タブを増やすメソッド
     */
    void addNewTab(TabPane pane){
        String title = "名無しタブ";
        
        // 現在のタブの数を取得し，新たなタブの名前を決定
        //title = "TAB"+(pane.getTabs().size() + 1); 
        //課題２：上をコメントを外して動作の違いを確認する。
        //さらに、課題１の削除ボタンと組み合わせて，削除と生成を繰り返して挙動をみる
        
        // 新たにタブを生成
        Tab newTab = new Tab(title);
        
        // 本来であればここに生成されるタブの内容(コントロールの生成・配置)を定義する
        
        // タブペインに追加
        pane.getTabs().add(newTab);
    }
    
    /**
     * JavaFXアプリケーションを起動するだけのメインメソッド
     * ※基本的にはこの内容で固定と考えてよい
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);  // JavaFXアプリケーションを起動する
    }
}