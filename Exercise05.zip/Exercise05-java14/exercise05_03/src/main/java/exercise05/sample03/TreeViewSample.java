package exercise05.sample03;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * TreeViewのサンプル
 * @author 出展：日向俊二著「JavaFX&Java8プログラミング」
 */
public class TreeViewSample extends Application {

    /**
     * GUIのメインメソッド
     * @param stage
     * @throws Exception 
     */
    @Override
    public void start(Stage stage) throws Exception {
        stage.setTitle("TreeVwSmpl");
        stage.setWidth(260);
        stage.setHeight(220);

        Label status = new Label();

        // TreeViewのトップメニューとして「メニュー」を生成
        TreeItem<String> rootnode = new TreeItem<>("メニュー");
        rootnode.setExpanded(true);
        
        // メニュー配下に「丼もの」の項目を追加
        TreeItem<String> donnode = new TreeItem<>("丼もの");
        rootnode.getChildren().add(donnode);
        
        // 丼ものとしてメニューを追加
        TreeItem<String> donitem0 = new TreeItem<>("かつ丼");
        TreeItem<String> donitem1 = new TreeItem<>("親子丼");
        TreeItem<String> donitem2 = new TreeItem<>("天丼");
        donnode.getChildren().add(donitem0);
        donnode.getChildren().add(donitem1);
        donnode.getChildren().add(donitem2);

        // メニュー配下に「麺類」の項目を追加
        TreeItem<String> mennode = new TreeItem<>("麺類");
        rootnode.getChildren().add(mennode);
        
        // 麺類としてメニューを追加
        TreeItem<String> menitem1 = new TreeItem<>("ラーメン");
        TreeItem<String> menitem2 = new TreeItem<>("タヌキうどん");
        mennode.getChildren().add(menitem1);
        mennode.getChildren().add(menitem2);

        // TreeViewにメニューを登録
        TreeView<String> treeView = new TreeView<String>(rootnode);
        treeView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        // マウスクリックにより「項目が選択された」場合のイベント処理を設定
        treeView.setOnMouseClicked(event -> {
            // 選択された項目を取得する
            TreeItem<String> ti = treeView.getSelectionModel().selectedItemProperty().get();
            if (ti != null)
                status.setText(ti.getValue() + "が選択されました。");
        });
        
        // コントロールの配置と表示
        VBox root = new VBox();
        root.getChildren().addAll(treeView, status);

        stage.setScene(new Scene(root));
        stage.show();
    }
    
    /**
     * JavaFXアプリケーションを起動するだけのメインメソッド
     * ※基本的にはこの内容で固定と考えてよい
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);  // JavaFXアプリケーションを起動する
    }
}
