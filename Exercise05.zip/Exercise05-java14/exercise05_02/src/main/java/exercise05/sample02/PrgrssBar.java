package exercise05.sample02;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javafx.application.Application;
import javafx.concurrent.Task;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * プログレスバーを用いた進捗状態の表示例
 * @author 出展：日向俊二著「JavaFX&Java8プログラミング」
 */
public class PrgrssBar extends Application {

    // プログレスバー
    ProgressBar progressBar = new ProgressBar();

    /**
     * GUIのメインメソッド
     * @param stage
     * @throws Exception 
     */
    @Override
    public void start(Stage stage) throws Exception {
        stage.setTitle("PrgrssBar");
        stage.setWidth(380);
        stage.setHeight(120);

        // プログレスバーの設定
        progressBar.setProgress(0.0);
        progressBar.setPrefWidth(350);
        progressBar.setMaxWidth(350);

        // ステータスバー
        Label statusBar = new Label("[Start]をクリックしてください．");
        VBox vBox = new VBox();
        vBox.setSpacing(5);
        vBox.setAlignment(Pos.CENTER);

        // [Start]ボタン
        Button button = new Button("Start");
        // setOnActionに渡す際にその場でEventHandlerクラスを定義＆生成して渡している
        button.setOnAction(new EventHandler<ActionEvent>() { 
            @Override
            public void handle(ActionEvent t) {
                // ダミーの重たい処理
                final Task<String> task = getTask();
                // 重たい処理とプログレスバーを同期させる
                progressBar.progressProperty().unbind();
                progressBar.progressProperty().bind(task.progressProperty());
                statusBar.textProperty().bind(task.messageProperty());
                // スレッドを生成して重たい処理を実行させる
                final ExecutorService exe = Executors.newSingleThreadExecutor();
                exe.submit(task);
                task.addEventHandler(WorkerStateEvent.WORKER_STATE_SUCCEEDED,
                    new EventHandler<WorkerStateEvent>() {
                    @Override
                    public void handle(WorkerStateEvent t) {
                        exe.shutdown();
                    }
                });
            }
        });

        // レイアウトと表示
        VBox root = new VBox();
        root.getChildren().addAll(button, progressBar, statusBar);

        stage.setScene(new Scene(root));
        stage.show();
    }

    /**
     * スレッドにやらせるダミーの計算処理
     * @return 計算結果
     */
    private Task<String> getTask() {
        return new Task<String>() {
            @Override
            protected String call() throws Exception {
                updateMessage("Start");
                double done = 0.0;
                while (done < 100.1) {
                    updateProgress(done, 100);
                    Thread.sleep(200);
                    String s = String.format("%d%% 完了", (int)done);
                    updateMessage(s);
                    done += 5;
                }
                updateMessage("完了");
                return "Done";
            }
        };
    }

    /**
     * JavaFXアプリケーションを起動するだけのメインメソッド
     * ※基本的にはこの内容で固定と考えてよい
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);  // JavaFXアプリケーションを起動する
    }

}
