package exercise05.sample05;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

/**
 * Chartクラスによるグラフ表示のサンプル
 * @author 出展：日向俊二著「JavaFX&Java8プログラミング」
 */
public class ChartSamples extends Application {
    /**
     * GUIのメインメソッド
     * @param stage
     * @throws Exception 
     */
    @Override
    public void start(Stage stage) throws Exception {
        // ベースとなるタブペインの生成
        TabPane tabPane = new TabPane();
        
        // 各タブを個別に削除できないようにする
	tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
        // 課題１：↑をコメント化して実行し，タブに削除ボタンが追加されていることを確認する。
        
        // タブごとに異なるチャートのサンプルを表示する
        Tab tab1 = new Tab("PieChart");
        tab1.setContent(panePieChart());

        Tab tab2 = new Tab("LineChart");
        tab2.setContent(paneLineChart());

        Tab tab3 = new Tab("BarChart");
        tab3.setContent(paneBarChart());

        Tab tab4 = new Tab("StackedBarChart");
        tab4.setContent(paneStackedBarChart());

        Tab tab5 = new Tab("AreaChart");
        tab5.setContent(paneAreaChart());

        Tab tab6 = new Tab("StackedAreaChart");
        tab6.setContent(paneStackedAreaChart());

        Tab tab7 = new Tab("ScatterChart");
        tab7.setContent(paneScatterChart());

        Tab tab8 = new Tab("BubbleChart");
        tab8.setContent(paneBubbleChart());
        
        
    	// タブをタブペインに登録
        tabPane.getTabs().addAll(tab1, tab2, tab3, tab4, tab5, tab6, tab7, tab8);
        
        // 画面へのタブの配置と出力
        BorderPane root = new BorderPane(tabPane);
        Scene scene = new Scene(root, 650, 650);
        stage.setScene(scene);
        stage.show();
    }
    
    /**
     * PieChartの例
     */
    Pane panePieChart(){
        ObservableList<PieChart.Data> pieData =
                FXCollections.observableArrayList(
                        new PieChart.Data("パン",  13),
                        new PieChart.Data("そば",  10),
                        new PieChart.Data("ラーメン",  22),
                        new PieChart.Data("カレー",  20));
        final PieChart chart = new PieChart(pieData);
        chart.setTitle("お昼はなに？");

        BorderPane root = new BorderPane();
        root.setCenter(chart);
        return root;
    }
    
    /**
     * LineChartの例
     */
    Pane paneLineChart(){
        NumberAxis xAxis = new NumberAxis();
        xAxis.setLabel("年齢");
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("発症率（%）");

        LineChart<Number, Number> lineChart = new LineChart<>(xAxis, yAxis);
        lineChart.setTitle("年齢と発症率");
        XYChart.Series<Number, Number> xyChartSeries = new XYChart.Series<>();
        xyChartSeries.setName("発症率");

        xyChartSeries.getData().add(new XYChart.Data<>(15, 22));
        xyChartSeries.getData().add(new XYChart.Data<>(20, 31));
        xyChartSeries.getData().add(new XYChart.Data<>(25, 36));
        xyChartSeries.getData().add(new XYChart.Data<>(30, 32));
        xyChartSeries.getData().add(new XYChart.Data<>(35, 35));
        xyChartSeries.getData().add(new XYChart.Data<>(40, 36));
        xyChartSeries.getData().add(new XYChart.Data<>(45, 40));
        xyChartSeries.getData().add(new XYChart.Data<>(50, 42));
        xyChartSeries.getData().add(new XYChart.Data<>(55, 45));
        xyChartSeries.getData().add(new XYChart.Data<>(60, 46));

        lineChart.getData().add(xyChartSeries);

        HBox root = new HBox();
        root.getChildren().add(lineChart);
        return root;
    }

    /**
     * BarChartの例
     */
    Pane paneBarChart(){
        CategoryAxis xAxis = new CategoryAxis();
        xAxis.setLabel("年度");
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("店舗数");
 
        BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);
        barChart.setTitle("店舗数の推移");
        XYChart.Series<String, Number> xyChartSeries = new XYChart.Series<>();
        xyChartSeries.setName("店舗数");
 
        xyChartSeries.getData().add(new XYChart.Data<>("1960", 2102));
        xyChartSeries.getData().add(new XYChart.Data<>("1970", 2453));
        xyChartSeries.getData().add(new XYChart.Data<>("1980", 2363));
        xyChartSeries.getData().add(new XYChart.Data<>("1990", 2389));
        xyChartSeries.getData().add(new XYChart.Data<>("2000", 2563));
        xyChartSeries.getData().add(new XYChart.Data<>("2010", 2856));
 
        barChart.getData().add(xyChartSeries);
 
        HBox root = new HBox();
        root.getChildren().add(barChart);
        return root;
    }

    /**
     * StackedBarChartの例
     */
    Pane paneStackedBarChart(){
        CategoryAxis xAxis = new CategoryAxis();
        xAxis.setLabel("年度");
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("人数");
 
        StackedBarChart<String, Number> barChart = new StackedBarChart<>(xAxis, yAxis);
        barChart.setTitle("参加者数の推移");

        XYChart.Series<String, Number> xyChartSeries1 = new XYChart.Series<>();
        xyChartSeries1.setName("男性");
        xyChartSeries1.getData().add(new XYChart.Data<>("1960", 32));
        xyChartSeries1.getData().add(new XYChart.Data<>("1970", 45));
        xyChartSeries1.getData().add(new XYChart.Data<>("1980", 63));
        xyChartSeries1.getData().add(new XYChart.Data<>("1990", 89));
        xyChartSeries1.getData().add(new XYChart.Data<>("2000", 63));
        xyChartSeries1.getData().add(new XYChart.Data<>("2010", 85));
 
        XYChart.Series<String, Number> xyChartSeries2 = new XYChart.Series<>();
        xyChartSeries2.setName("女性");
        xyChartSeries2.getData().add(new XYChart.Data<>("1960", 22));
        xyChartSeries2.getData().add(new XYChart.Data<>("1970", 23));
        xyChartSeries2.getData().add(new XYChart.Data<>("1980", 23));
        xyChartSeries2.getData().add(new XYChart.Data<>("1990", 29));
        xyChartSeries2.getData().add(new XYChart.Data<>("2000", 25));
        xyChartSeries2.getData().add(new XYChart.Data<>("2010", 26));

        barChart.getData().add(xyChartSeries1);
        barChart.getData().add(xyChartSeries2);
 
        HBox root = new HBox();
        root.getChildren().add(barChart);
        return root;
    }

    /**
     * AreaChartの例
     */
    @SuppressWarnings("unchecked")
    Pane paneAreaChart(){
        NumberAxis xAxis = new NumberAxis(2011, 2020, 1);
        NumberAxis yAxis = new NumberAxis(1000, 1800, 100);
        AreaChart<Number, Number> chart = new AreaChart<>(xAxis, yAxis);

        // 男性人口のデータ
        XYChart.Series<Number, Number> dataM = new XYChart.Series<>();
        dataM.setName("男性");
        dataM.getData().add(new Data<>(2011, 1232));
        dataM.getData().add(new Data<>(2012, 1236));
        dataM.getData().add(new Data<>(2013, 1271));
        dataM.getData().add(new Data<>(2014, 1288));
        dataM.getData().add(new Data<>(2015, 1310));
        dataM.getData().add(new Data<>(2016, 1323));
        dataM.getData().add(new Data<>(2017, 1452));
        dataM.getData().add(new Data<>(2018, 1460));
        dataM.getData().add(new Data<>(2019, 1507));
        dataM.getData().add(new Data<>(2020, 1607));
        // 女性人口のデータ
        XYChart.Series<Number, Number> dataF = new XYChart.Series<>();
        dataF.setName("女性");
        dataF.getData().add(new Data<>(2011, 1122));
        dataF.getData().add(new Data<>(2012, 1182));
        dataF.getData().add(new Data<>(2013, 1236));
        dataF.getData().add(new Data<>(2014, 1296));
        dataF.getData().add(new Data<>(2015, 1322));
        dataF.getData().add(new Data<>(2016, 1356));
        dataF.getData().add(new Data<>(2017, 1466));
        dataF.getData().add(new Data<>(2018, 1589));
        dataF.getData().add(new Data<>(2019, 1699));
        dataF.getData().add(new Data<>(2020, 1725));
        chart.setData(FXCollections.observableArrayList(dataM, dataF));
        
        chart.setTitle("人口推移");

        BorderPane root = new BorderPane();
        root.setCenter(chart);
        return root;
    }

    /**
     * StackedAreaChartの例
     */
    Pane paneStackedAreaChart(){
        NumberAxis xAxis = new NumberAxis(2011, 2020, 1);
        NumberAxis yAxis = new NumberAxis(0, 4000, 100);
        StackedAreaChart<Number, Number> chart = new StackedAreaChart<>(xAxis, yAxis);

        // 男性人口のデータ
        XYChart.Series<Number, Number> dataM = new XYChart.Series<>();
        dataM.setName("男性");
        dataM.getData().add(new Data<>(2011, 1232));
        dataM.getData().add(new Data<>(2012, 1236));
        dataM.getData().add(new Data<>(2013, 1271));
        dataM.getData().add(new Data<>(2014, 1288));
        dataM.getData().add(new Data<>(2015, 1310));
        dataM.getData().add(new Data<>(2016, 1323));
        dataM.getData().add(new Data<>(2017, 1452));
        dataM.getData().add(new Data<>(2018, 1460));
        dataM.getData().add(new Data<>(2019, 1507));
        dataM.getData().add(new Data<>(2020, 1607));
        // 女性人口のデータ
        XYChart.Series<Number, Number> dataF = new XYChart.Series<>();
        dataF.setName("女性");
        dataF.getData().add(new Data<>(2011, 1122));
        dataF.getData().add(new Data<>(2012, 1182));
        dataF.getData().add(new Data<>(2013, 1236));
        dataF.getData().add(new Data<>(2014, 1296));
        dataF.getData().add(new Data<>(2015, 1322));
        dataF.getData().add(new Data<>(2016, 1356));
        dataF.getData().add(new Data<>(2017, 1466));
        dataF.getData().add(new Data<>(2018, 1589));
        dataF.getData().add(new Data<>(2019, 1699));
        dataF.getData().add(new Data<>(2020, 1725));
        chart.getData().add(dataM);
        chart.getData().add(dataF);
     
        chart.setTitle("人口推移");

        BorderPane root = new BorderPane();
        root.setCenter(chart);
        return root;
    }

    /**
     * ScatterChartの例
     */
    Pane paneScatterChart(){
        NumberAxis xAxis = new NumberAxis();
        xAxis.setLabel("駅からの距離");
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("価格");

        ScatterChart<Number, Number> scatterChart = new ScatterChart<>(xAxis, yAxis);
        scatterChart.setTitle("駅からの距離と価格");
        XYChart.Series<Number, Number> xyChartSeries = new XYChart.Series<>();
        xyChartSeries.setName("価格（万円）");

        xyChartSeries.getData().add(new XYChart.Data<>(5, 4500));
        xyChartSeries.getData().add(new XYChart.Data<>(8, 3830));
        xyChartSeries.getData().add(new XYChart.Data<>(12, 3650));
        xyChartSeries.getData().add(new XYChart.Data<>(13, 3400));
        xyChartSeries.getData().add(new XYChart.Data<>(14, 3010));
        xyChartSeries.getData().add(new XYChart.Data<>(14, 3550));
        xyChartSeries.getData().add(new XYChart.Data<>(14, 3410));
        xyChartSeries.getData().add(new XYChart.Data<>(15, 3200));
        xyChartSeries.getData().add(new XYChart.Data<>(17, 3100));
        xyChartSeries.getData().add(new XYChart.Data<>(19, 2980));
        xyChartSeries.getData().add(new XYChart.Data<>(22, 2900));
        xyChartSeries.getData().add(new XYChart.Data<>(28, 2200));

        scatterChart.getData().add(xyChartSeries);

        HBox root = new HBox();
        root.getChildren().add(scatterChart);
        return root;
    }

    /**
     * BubbleChartの例
     */
    Pane paneBubbleChart(){
        NumberAxis xAxis = new NumberAxis();
        xAxis.setLabel("人口」（万人）");
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("面積（ha）");

        BubbleChart<Number, Number> bubbleChart = new BubbleChart<>(xAxis, yAxis);
        bubbleChart.setTitle("面積/人口と施設数");
        XYChart.Series<Number, Number> xyChartSeries = new XYChart.Series<>();
        xyChartSeries.setName("施設数");

        xyChartSeries.getData().add(new XYChart.Data<>(160, 102, 5));
        xyChartSeries.getData().add(new XYChart.Data<>(190, 453, 12));
        xyChartSeries.getData().add(new XYChart.Data<>(180, 363, 15));
        xyChartSeries.getData().add(new XYChart.Data<>(156, 256, 7));
        xyChartSeries.getData().add(new XYChart.Data<>(210, 463, 18));
        xyChartSeries.getData().add(new XYChart.Data<>(155, 326, 14));

        bubbleChart.getData().add(xyChartSeries);

        HBox root = new HBox();
        root.getChildren().add(bubbleChart);
        return root;
    }
    /**
     * JavaFXアプリケーションを起動するだけのメインメソッド
     * ※基本的にはこの内容で固定と考えてよい
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);  // JavaFXアプリケーションを起動する
    }
}
