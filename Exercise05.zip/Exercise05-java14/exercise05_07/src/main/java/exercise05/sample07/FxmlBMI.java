package exercise05.sample07;

import static javafx.application.Application.launch;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXMLによるGUIデザインのサンプル
 * @author 出展：日向俊二著「JavaFX&Java8プログラミング」
 */
public class FxmlBMI extends Application {
    /**
     * GUIのメインメソッド
     * @param stage
     * @throws Exception 
     */
    @Override
    public void start(Stage stage) throws Exception {
        stage.setTitle("FxmlBMI");
        
        // FXMLファイルの読み込み
        FXMLLoader fxml = new FXMLLoader(getClass().getResource("fxmlBMI.fxml"));
        
        // GUIの設定と表示
        AnchorPane root = fxml.load();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    // FXMLファイル内で定義したオブジェクトのフィールド変数として利用するための宣言
    @FXML
    private TextField txtHeight;
    @FXML
    private TextField txtWeight;
    @FXML
    private Label txtBMI;

    // イベント処理部のみソース側で実装(ファイル中ではonCalcClickedメソッドを呼ぶとだけ指定)
    @FXML  // OKボタンがクリックされた
    public void onCalcClicked(ActionEvent event) {
        double h = Double.parseDouble(txtHeight.getText()) * 0.01;
        double w = Double.parseDouble(txtWeight.getText());
        String result = String.format("BMI=%5.2f", (w / (h * h)));
        txtBMI.setText(result);
    }
    
    /**
     * JavaFXアプリケーションを起動するだけのメインメソッド
     * ※基本的にはこの内容で固定と考えてよい
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);  // JavaFXアプリケーションを起動する
    }
}
