package exercise05.sample01;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * スライダーのサンプル
 * @author 出展：日向俊二著「JavaFX&Java8プログラミング」
 */
public class BMI extends Application {

    // 身長と体重の入力用スライダー
    Slider sliderH = new Slider(100, 200, 170.0);
    Slider sliderW = new Slider(20, 120, 60.0);

    // スライダーの選択値を表示するラベル
    Label lblWv = new Label();
    Label lblHv = new Label();

    // BMI値を出力するラベル
    Label lblBMI = new Label("BMI");

    /**
     * GUIのメインメソッド
     * @param stage
     * @throws Exception 
     */
    @Override
    public void start(Stage stage) throws Exception {
        stage.setTitle("BMI");
        stage.setWidth(400);
        stage.setHeight(230);

        // 身長のスライダーの設定
        Label lblH = new Label("　身長：");
        sliderH.setPrefWidth(280);
        sliderH.setOrientation(Orientation.HORIZONTAL);
        sliderH.setShowTickMarks(true);
        sliderH.setShowTickLabels(true);
        sliderH.setMajorTickUnit(50.0f);
        sliderH.setBlockIncrement(5.0f);
        lblHv.setText(sliderH.getValue() + "cm");
        sliderH.setOnMouseClicked(event -> updateValue());
        sliderH.setOnKeyPressed(event -> updateValue());

        // スライダーのわきに現在値を表示する
        HBox boxH = new HBox();
        boxH.getChildren().addAll(lblH, sliderH, lblHv);

        // 体重のスライダーの設定
        Label lblW = new Label("　体重：");
        sliderW.setPrefWidth(280);
        sliderW.setOrientation(Orientation.HORIZONTAL);
        sliderW.setShowTickMarks(true);
        sliderW.setShowTickLabels(true);
        sliderW.setMajorTickUnit(50.0f);
        sliderW.setBlockIncrement(5.0f);
        lblHv.setText(sliderW.getValue() + "kg");
        sliderW.setOnMouseClicked(event -> updateValue());
        sliderW.setOnKeyPressed(event -> updateValue());

        // スライダーのわきに現在値を表示する
        HBox boxW = new HBox();
        boxW.getChildren().addAll(lblW, sliderW, lblWv);

        // ２つのスライダーとＢＭＩの計算結果を縦に並べて表示
        VBox root = new VBox();
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(1, 1, 1, 1));
        root.setSpacing(20.0);
        root.getChildren().addAll(boxH, boxW, lblBMI);

        // スライダーの初期値でＢＭＩを算出
        updateValue();

        // シーンの割当てと表示
        stage.setScene(new Scene(root));
        stage.show();
    }

    /**
     * 現在のスライダーの値を基にＢＭＩを算出し，結果欄に出力する
     */
    void updateValue(){
        double h = sliderH.getValue();
        double w = sliderW.getValue();
        lblHv.setText(String.format("%5.1f", h) + "cm");
        lblWv.setText(String.format("%5.1f", w) + "kg");
        double bmi = 10000.0 * w / (h * h);
        lblBMI.setText(String.format("BMI=%5.2f", bmi));
    }
    
    /**
     * JavaFXアプリケーションを起動するだけのメインメソッド
     * ※基本的にはこの内容で固定と考えてよい
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);  // JavaFXアプリケーションを起動する
    }
    
}

