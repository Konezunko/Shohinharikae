package exercise05.stackpane;

import javafx.application.*;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * JavaFXのStackPaneのサンプル
 * @author Kazuhiko Sato
 */
public class StackPaneSample extends Application{
    @Override
    public void start(Stage stage) throws Exception {
        stage.setTitle("StackPaneサンプル");
        stage.setWidth(240);
        stage.setHeight(140);
        
        Label lblStatus = new Label();
        
        //-------------------------------------------
        // ボタンを3個作る
        //-------------------------------------------
        Button button[] = new Button[3];
        for(int i=0; i < button.length; i++){
            button[i] = new Button("button "+Integer.toString(i));
            // ボタン上のテキスト表示位置を上段(TOP)左揃え(LEFT)に設定
            button[i].setAlignment(Pos.TOP_LEFT);
            // ボタンのサイズをiの値で少しずつ変更する
            button[i].setPrefWidth(80+i*80);
            button[i].setPrefHeight(30+i*20);
            // 押されたときのアクションを設定(ラベルのメッセージを変更)
            String message = String.format("button %d がクリックされました。",i);
            button[i].setOnAction(event->lblStatus.setText(message));
        }
        
        //============================================
        // ボタンを並べるStackPaneのレイアウト
        //============================================
        StackPane pane = new StackPane();
        // Pane上のボタン配置を下段右揃えにする(サイズが違うので重なって見える)
        pane.setAlignment(Pos.BOTTOM_RIGHT);
        // ボタンを順番に配置
        pane.getChildren().addAll(button[2],button[1],button[0]);
        
        //============================================
        // ラベルとボタンを並べたBorderを縦配置するVBoxレイアウト
        //============================================
        VBox base = new VBox();
        base.getChildren().addAll(pane,lblStatus);
        
        //-------------------------------------------
        // StageにSceneを設定し、描画開始
        //-------------------------------------------
        stage.setScene(new Scene(base));
        stage.show();
        
    }
    
    /**
     * 起動用のmainメソッド
     * @param args 
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
