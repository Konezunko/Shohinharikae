package exercise05.sample04;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * TableViewのサンプル
 * @author 出展：日向俊二著「JavaFX&Java8プログラミング」
 */
public class TableViewSample extends Application {

    /**
     * GUIのメインメソッド
     * @param stage
     * @throws Exception 
     */
    @SuppressWarnings("unchecked")
    @Override
    public void start(Stage stage) throws Exception {
        stage.setTitle("TableVw");
        stage.setWidth(260);
        stage.setHeight(180);

        // 表示対象となるPerson型のオブジェクトからなるリストを生成
        ObservableList<Person> data = FXCollections.observableArrayList(
        		new Person("花岡", "実太", "Hanaoka@gmail.cam"),
        		new Person("山田", "花子", "HanakoY@hmail.cam"),
        		new Person("羽生", "譲", "Hanyu@yaho.ca.jp"),
        		new Person("織田", "猿男", "Saru@gmail.cam")
        		);
        
        // TableViewの生成と設定
        TableView<Person> table = new TableView<>();
        // TableViewで表示されるデータとして上で生成したリストを指定
        table.itemsProperty().setValue(data);
        
        // 列情報の設定
        TableColumn<Person, String> seiColumn = new TableColumn<>("姓");        // 列の設定
        TableColumn<Person, String> meiColumn = new TableColumn<>("名");        // 列の設定
        TableColumn<Person, String> eMailColumn = new TableColumn<>("Eメール"); // 列の設定
        // 登録したデータ内の項目と表示列を対応付ける
        seiColumn.setCellValueFactory(new PropertyValueFactory<Person, String>("sei"));
        meiColumn.setCellValueFactory(new PropertyValueFactory<Person, String>("mei"));
        eMailColumn.setCellValueFactory(new PropertyValueFactory<Person, String>("eMail"));
        // 列を表に割り当てる
        table.getColumns().addAll(seiColumn, meiColumn, eMailColumn);

        // コントロールの配置と描画
        VBox root = new VBox();
        root.getChildren().addAll(table);

        stage.setScene(new Scene(root));
        stage.show();
    }
    
    /**
     * JavaFXアプリケーションを起動するだけのメインメソッド
     * ※基本的にはこの内容で固定と考えてよい
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);  // JavaFXアプリケーションを起動する
    }
}

