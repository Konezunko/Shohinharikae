package exercise05.sample04;

/**
 * テーブルに表示されるデータクラス
 * @author 出展：日向俊二著「JavaFX&Java8プログラミング」
 */
public class Person {
	private String sei;     // 性
	private String mei;     // 名
	private String eMail;   // e-mail

        /*
         * コンストラクタ
         */
	public Person( String sei, String mei, String eMail){
		this.sei = sei;
		this.mei = mei;
		this.eMail = eMail;
	}

        /*
         *  ゲッター＆セッター 
         */
	public String getSei() {
		return sei;
	}
	public void setSei(String sei) {
		this.sei = sei;
	}
	public String getMei() {
		return mei;
	}
	public void setMei(String mei) {
		this.mei = mei;
	}
	public String getEMail() {
		return eMail;
	}
	public void setEMail(String eMail) {
		this.eMail = eMail;
	}
}
