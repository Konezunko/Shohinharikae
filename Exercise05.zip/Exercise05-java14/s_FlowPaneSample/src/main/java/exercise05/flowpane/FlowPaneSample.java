package exercise05.flowpane;

import javafx.application.*;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.Scene;
import javafx.stage.Stage;

/*
   FlowPaneのサンプルの使い方
   表示されるウィンドウのフレームをドラッグして、ウィンドウのサイズを
   適当に変化させ、配置が自動的に変わることを確認する。
*/

/**
 * JavaFXのFlowPaneのサンプル
 * @author Kazuhiko Sato
 */
public class FlowPaneSample extends Application{
    @Override
    public void start(Stage stage) throws Exception {
        stage.setTitle("FlowPaneサンプル");
        
        // ボタンを10個並べる
        Button button[] = new Button[10];
        for(int i=0; i< button.length; i++){
            button[i] = new Button(Integer.toString(i)); // ボタン実体を生成(ラベルはi)
            button[i].setPrefWidth(80);
        }
        
        // FlowPaneにボタンを配置する
        FlowPane base = new FlowPane();
        base.setPadding(new Insets(10,10,10,10)); // ボタンの配置位置を外周10pt内側に指定
        base.getChildren().addAll(button); // レイアウトにボタン配列をまとめて登録
        
        // StageにSceneを設定し、描画開始
        stage.setScene(new Scene(base));
        stage.show();
        
    }
    
    /**
     * 起動用のmainメソッド
     * @param args 
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
